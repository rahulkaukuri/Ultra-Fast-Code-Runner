#include <iostream>

int main(void)
{
    printf("OK");
    return 0;
}